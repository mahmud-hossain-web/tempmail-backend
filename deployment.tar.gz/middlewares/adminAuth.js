"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.adminAuthOrDev = exports.requireSuperAdmin = exports.requireAdmin = void 0;
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const JWT_SECRET = process.env.JWT_SECRET || 'super-secret-tempmail-key-123';
// Admin emails whitelist (same as frontend)
const ADMIN_EMAILS = ['mahmudhasan01726@gmail.com'];
/**
 * Middleware: Verify JWT and check admin role
 */
const requireAdmin = (req, res, next) => {
    try {
        const authHeader = req.headers.authorization;
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            return res.status(401).json({ error: 'Unauthorized: No token provided' });
        }
        const token = authHeader.split(' ')[1];
        const decoded = jsonwebtoken_1.default.verify(token, JWT_SECRET);
        // Check if user email is in admin whitelist or has admin/superadmin role
        if (!ADMIN_EMAILS.includes(decoded.email) && !['admin', 'superadmin'].includes(decoded.role)) {
            return res.status(403).json({ error: 'Forbidden: Admin access required' });
        }
        req.admin = decoded;
        next();
    }
    catch (error) {
        return res.status(401).json({ error: 'Unauthorized: Invalid or expired token' });
    }
};
exports.requireAdmin = requireAdmin;
/**
 * Middleware: Require superadmin role for destructive operations
 */
const requireSuperAdmin = (req, res, next) => {
    try {
        const authHeader = req.headers.authorization;
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            return res.status(401).json({ error: 'Unauthorized: No token provided' });
        }
        const token = authHeader.split(' ')[1];
        const decoded = jsonwebtoken_1.default.verify(token, JWT_SECRET);
        if (decoded.role !== 'superadmin' && decoded.email !== 'mahmudhasan01726@gmail.com') {
            return res.status(403).json({ error: 'Forbidden: Super Admin access required' });
        }
        req.admin = decoded;
        next();
    }
    catch (error) {
        return res.status(401).json({ error: 'Unauthorized: Invalid or expired token' });
    }
};
exports.requireSuperAdmin = requireSuperAdmin;
/**
 * Dev bypass: Skip auth in development when ADMIN_DEV_BYPASS=true
 */
const adminAuthOrDev = (req, res, next) => {
    if (process.env.ADMIN_DEV_BYPASS === 'true') {
        req.admin = { id: 'dev', email: 'dev@tempworld.org', role: 'superadmin' };
        return next();
    }
    return (0, exports.requireAdmin)(req, res, next);
};
exports.adminAuthOrDev = adminAuthOrDev;
