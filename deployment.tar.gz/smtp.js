"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.startSMTPServer = exports.inMemoryInbox = void 0;
const smtp_server_1 = require("smtp-server");
const mailparser_1 = require("mailparser");
let ioInstance;
const redis_1 = __importDefault(require("./redis"));
const firebaseAdmin_1 = require("./utils/firebaseAdmin");
const admin = __importStar(require("firebase-admin"));
exports.inMemoryInbox = new Map();
const smtpOptions = {
    secure: false,
    authOptional: true,
    onData(stream, session, callback) {
        (0, mailparser_1.simpleParser)(stream, async (err, parsed) => {
            if (err) {
                console.error("Parse Error:", err);
            }
            else {
                try {
                    const recipients = session.envelope.rcptTo.map((r) => r.address);
                    for (let recipient of recipients) {
                        recipient = (recipient || '').toLowerCase();
                        console.log(`New mail received for target address: ${recipient}`);
                        const messageData = {
                            id: Date.now().toString(),
                            sender: parsed.from?.text || 'Unknown',
                            subject: parsed.subject || 'No Subject',
                            time: new Date().toLocaleTimeString(),
                            body: parsed.text || parsed.html || '',
                        };
                        // emit realtime
                        if (ioInstance) {
                            ioInstance.to(recipient).emit('new_email', messageData);
                        }
                        // save in memory
                        const currentMessages = exports.inMemoryInbox.get(recipient) || [];
                        exports.inMemoryInbox.set(recipient, [messageData, ...currentMessages]);
                        // save in firebase
                        if (firebaseAdmin_1.db) {
                            try {
                                const docRef = firebaseAdmin_1.db.collection('messages').doc(messageData.id);
                                await docRef.set({
                                    ...messageData,
                                    recipient: recipient,
                                    timestamp: admin.firestore.FieldValue.serverTimestamp()
                                });
                            }
                            catch (error) {
                                console.error("Firebase DB error saving email", error);
                            }
                        }
                        // cache to redis (for reconnects)
                        if (redis_1.default.isOpen) {
                            try {
                                await redis_1.default.lPush(`inbox:${recipient}`, JSON.stringify(messageData));
                            }
                            catch (err) {
                                console.error("Redis Error saving email", err);
                            }
                        }
                    }
                }
                catch (internalError) {
                    console.error("Internal processing error:", internalError);
                }
            }
            callback();
        });
    }
};
const server = new smtp_server_1.SMTPServer(smtpOptions);
const startSMTPServer = (port = 25, ioObj) => {
    if (ioObj)
        ioInstance = ioObj;
    server.listen(port, () => {
        console.log(`SMTP server listening on port ${port}`);
    });
};
exports.startSMTPServer = startSMTPServer;
