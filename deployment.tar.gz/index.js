"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.io = void 0;
const express_1 = __importDefault(require("express"));
const http_1 = require("http");
const socket_io_1 = require("socket.io");
const cors_1 = __importDefault(require("cors"));
const helmet_1 = __importDefault(require("helmet"));
const express_rate_limit_1 = __importDefault(require("express-rate-limit"));
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const smtp_1 = require("./smtp");
const firebaseAdmin_1 = require("./utils/firebaseAdmin");
const admin = __importStar(require("firebase-admin"));
const redis_1 = __importDefault(require("./redis"));
const admin_1 = __importDefault(require("./routes/admin"));
const nodemailer_1 = __importDefault(require("nodemailer"));
const otpStore = new Map();
const transporter = nodemailer_1.default.createTransport({
    sendmail: true,
    newline: 'unix',
    path: '/usr/sbin/sendmail'
});
const WORKER_SECRET = process.env.WORKER_SECRET || 'your-secret-key';
const app = (0, express_1.default)();
const httpServer = (0, http_1.createServer)(app);
exports.io = new socket_io_1.Server(httpServer, {
    cors: { origin: '*' }
});
app.use((0, helmet_1.default)());
app.use((0, cors_1.default)());
app.use(express_1.default.json());
const apiLimiter = (0, express_rate_limit_1.default)({
    windowMs: 15 * 60 * 1000,
    max: 100, // 100 requests per 15 minutes
});
app.use('/api', apiLimiter);
// Admin dashboard API routes
app.use('/api/admin', admin_1.default);
// Mock API Key Middleware for Developers
const developerApiAuth = (req, res, next) => {
    const apiKey = req.headers['x-api-key'];
    if (!apiKey) {
        return res.status(401).json({ error: 'Unauthorized: Missing x-api-key header' });
    }
    // In production, validate this against the DB for premium users
    if (apiKey !== 'test_developer_key' && apiKey.length < 10) {
        return res.status(401).json({ error: 'Unauthorized: Invalid API Key' });
    }
    next();
};
app.get('/api/health', (req, res) => {
    res.json({ status: 'OK', uptime: process.uptime() });
});
// ============================================
// Cloudflare Email Worker - Incoming Email
// ============================================
app.post('/api/incoming-email', async (req, res) => {
    try {
        // 1. Verify the worker secret
        const secret = req.headers['x-worker-secret'];
        if (secret !== WORKER_SECRET) {
            console.warn('Unauthorized incoming email attempt');
            return res.status(401).json({ error: 'Unauthorized' });
        }
        const { recipient, sender, subject, body, receivedAt } = req.body;
        if (!recipient) {
            return res.status(400).json({ error: 'Recipient is required' });
        }
        const safeRecipient = (recipient || '').toLowerCase();
        console.log(`📩 Incoming email from Cloudflare Worker for: ${safeRecipient}`);
        const messageData = {
            id: Date.now().toString(),
            sender: sender || 'Unknown',
            subject: subject || 'No Subject',
            time: new Date(receivedAt || Date.now()).toLocaleTimeString(),
            body: body || '',
        };
        // 2. Emit via Socket.io for real-time inbox
        exports.io.to(safeRecipient).emit('new_email', messageData);
        // 3. Save in memory
        const currentMessages = smtp_1.inMemoryInbox.get(safeRecipient) || [];
        smtp_1.inMemoryInbox.set(safeRecipient, [messageData, ...currentMessages]);
        // 4. Save to Firebase
        if (firebaseAdmin_1.db) {
            try {
                const docRef = firebaseAdmin_1.db.collection('messages').doc(messageData.id);
                await docRef.set({
                    ...messageData,
                    recipient: safeRecipient,
                    timestamp: admin.firestore.FieldValue.serverTimestamp()
                });
            }
            catch (error) {
                console.error('Firebase DB error saving email:', error);
            }
        }
        // 5. Cache to Redis
        if (redis_1.default.isOpen) {
            try {
                await redis_1.default.lPush(`inbox:${safeRecipient}`, JSON.stringify(messageData));
            }
            catch (err) {
                console.error('Redis Error saving email:', err);
            }
        }
        console.log(`✅ Email processed successfully for ${safeRecipient}`);
        res.json({ success: true, message: 'Email received and processed' });
    }
    catch (error) {
        console.error('Error processing incoming email:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});
// Define a secret key. In production, get this from process.env.JWT_SECRET
const JWT_SECRET = process.env.JWT_SECRET || 'super-secret-tempmail-key-123';
app.post('/api/auth/send-otp', async (req, res) => {
    try {
        const { email } = req.body;
        if (!email)
            return res.status(400).json({ error: 'Email is required' });
        const code = Math.floor(100000 + Math.random() * 900000).toString();
        // 10 minute expiry
        otpStore.set(email.toLowerCase(), { code, expires: Date.now() + 10 * 60 * 1000 });
        const mailOptions = {
            from: '"TempWorld Support" <support@tempworld.org>',
            to: email,
            subject: 'Your Verification Code',
            text: `Your verification code is: ${code}\nIt will expire in 10 minutes.`,
            html: `<h3>Your verification code is: <strong>${code}</strong></h3><p>It will expire in 10 minutes.</p>`
        };
        transporter.sendMail(mailOptions, (err, info) => {
            if (err) {
                console.error("Error sending OTP email:", err);
                return res.status(500).json({ error: 'Failed to send OTP' });
            }
            res.json({ message: 'OTP sent successfully' });
        });
    }
    catch (err) {
        console.error('OTP processing error:', err);
        res.status(500).json({ error: 'Internal server error' });
    }
});
app.post('/api/auth/verify-otp', async (req, res) => {
    try {
        const { email, code } = req.body;
        if (!email || !code)
            return res.status(400).json({ error: 'Email and code are required' });
        const storedOtp = otpStore.get(email.toLowerCase());
        if (!storedOtp)
            return res.status(400).json({ error: 'No OTP found for this email. Please resend.' });
        if (Date.now() > storedOtp.expires) {
            otpStore.delete(email.toLowerCase());
            return res.status(400).json({ error: 'OTP has expired. Please request a new one.' });
        }
        if (storedOtp.code !== code) {
            return res.status(400).json({ error: 'Invalid OTP code' });
        }
        // Clean up
        otpStore.delete(email.toLowerCase());
        // Update Firebase User
        if (firebaseAdmin_1.auth) {
            try {
                const userRecord = await firebaseAdmin_1.auth.getUserByEmail(email);
                if (!userRecord.emailVerified) {
                    await firebaseAdmin_1.auth.updateUser(userRecord.uid, { emailVerified: true });
                }
            }
            catch (fbErr) {
                console.error('Firebase update error during OTP verification:', fbErr);
                // Continue anyway, maybe they don't have a Firebase account yet
            }
        }
        res.json({ message: 'Email verified successfully' });
    }
    catch (err) {
        console.error('OTP verification error:', err);
        res.status(500).json({ error: 'Internal server error' });
    }
});
app.post('/api/auth/firebase-login', async (req, res) => {
    try {
        const { idToken, name } = req.body;
        if (!idToken) {
            return res.status(400).json({ error: 'ID Token is required' });
        }
        // 1. Verify the Firebase token
        let decodedToken;
        if (firebaseAdmin_1.auth) {
            decodedToken = await firebaseAdmin_1.auth.verifyIdToken(idToken);
        }
        else {
            // Mock mode if Firebase Admin is not fully initialized in .env
            console.warn('[Mock Mode] Firebase Admin missing config. Proceeding as if token is valid.');
            decodedToken = { uid: 'mock-uid-123', email: 'mock@example.com' };
        }
        const email = decodedToken.email;
        const uid = decodedToken.uid;
        // 2. Here you would normally lookup the user in PostgreSQL
        if (firebaseAdmin_1.db) {
            try {
                const docRef = firebaseAdmin_1.db.collection('users').doc(uid);
                const doc = await docRef.get();
                if (!doc.exists) {
                    await docRef.set({
                        uid, email, name, createdAt: new Date()
                    });
                }
            }
            catch (error) {
                console.error("Firebase DB error saving user", error);
            }
        }
        console.log(`User logged in via Firebase: ${email} (${uid})`);
        // 3. Issue our own system's JWT
        const token = jsonwebtoken_1.default.sign({ id: uid, email: email, role: 'user' }, JWT_SECRET, { expiresIn: '7d' } // keep user logged in for 7 days
        );
        res.json({
            message: 'Login successful',
            token: token,
            user: { uid, email, name }
        });
    }
    catch (error) {
        console.error('Firebase Auth Error:', error);
        res.status(401).json({ error: 'Unauthorized. Invalid Firebase Token.' });
    }
});
app.get('/api/messages/:email', async (req, res) => {
    const email = (req.params.email || '').toLowerCase();
    if (firebaseAdmin_1.db) {
        try {
            const snapshot = await firebaseAdmin_1.db.collection('messages')
                .where('recipient', '==', email)
                .orderBy('timestamp', 'desc')
                .get();
            if (!snapshot.empty) {
                const messages = snapshot.docs.map(doc => {
                    const data = doc.data();
                    // Don't send internal timestamp to client if it fails
                    delete data.timestamp;
                    return data;
                });
                return res.json(messages);
            }
        }
        catch (error) {
            console.error("Firebase DB Error fetching messages:", error);
        }
    }
    const messages = smtp_1.inMemoryInbox.get(email) || [];
    res.json(messages);
});
// Developer API Endpoints
app.get('/api/developer/domains', developerApiAuth, (req, res) => {
    res.json({
        domains: ["appschai.site", "appschai.store", "appschai.space", "appschai.online", "appschai.website", "appschai.shop", "appschai.fun", "appschai.sbs"]
    });
});
app.post('/api/developer/generate', developerApiAuth, (req, res) => {
    const { domain } = req.body;
    const selectedDomain = domain || "appschai.site";
    const randomStr = Math.random().toString(36).substring(2, 10);
    res.json({ email: `${randomStr}@${selectedDomain}` });
});
app.get('/api/developer/messages/:email', developerApiAuth, async (req, res) => {
    const email = (req.params.email || '').toLowerCase();
    if (firebaseAdmin_1.db) {
        try {
            const snapshot = await firebaseAdmin_1.db.collection('messages')
                .where('recipient', '==', email)
                .orderBy('timestamp', 'desc')
                .get();
            if (!snapshot.empty) {
                const messages = snapshot.docs.map(doc => {
                    const data = doc.data();
                    delete data.timestamp;
                    return data;
                });
                return res.json({ count: messages.length, messages });
            }
        }
        catch (error) {
            console.error("Firebase DB Error fetching developer messages:", error);
        }
    }
    const messages = smtp_1.inMemoryInbox.get(email) || [];
    res.json({ count: messages.length, messages: messages });
});
app.delete('/api/developer/messages/:email', developerApiAuth, async (req, res) => {
    const email = (req.params.email || '').toLowerCase();
    smtp_1.inMemoryInbox.set(email, []);
    if (firebaseAdmin_1.db) {
        try {
            const snapshot = await firebaseAdmin_1.db.collection('messages')
                .where('recipient', '==', email)
                .get();
            const batch = firebaseAdmin_1.db.batch();
            snapshot.docs.forEach((doc) => {
                batch.delete(doc.ref);
            });
            await batch.commit();
        }
        catch (error) {
            console.error("Firebase DB Error deleting developer messages:", error);
        }
    }
    res.json({ success: true, message: 'Inbox cleared' });
});
exports.io.on('connection', (socket) => {
    console.log('Client connected:', socket.id);
    socket.on('subscribe_inbox', (email) => {
        const safeEmail = (email || '').toLowerCase();
        socket.join(safeEmail);
        console.log(`Socket ${socket.id} subscribed to ${safeEmail}`);
    });
    socket.on('disconnect', () => {
        console.log('Client disconnected:', socket.id);
    });
});
const PORT = process.env.PORT || 5000;
httpServer.listen(PORT, () => {
    console.log(`Server API & WebSocket listening on port ${PORT}`);
    const smtpPort = process.env.SMTP_PORT ? parseInt(process.env.SMTP_PORT) : 25;
    (0, smtp_1.startSMTPServer)(smtpPort, exports.io);
});
